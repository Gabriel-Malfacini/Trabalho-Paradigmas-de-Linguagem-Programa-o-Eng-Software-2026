import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa um Aluno com suas notas.
 * Demonstra: herança (extends Pessoa), encapsulamento e polimorfismo.
 */
public class Aluno extends Pessoa implements Comparable<Aluno> {

    private static final double MEDIA_APROVACAO = 6.0;

    private List<Double> notas;

    public Aluno(String nome) {
        super(nome);
        this.notas = new ArrayList<>();
    }

    /**
     * Adiciona uma nota ao aluno com validação.
     * Demonstra: tratamento de exceções (lança NotaInvalidaException).
     */
    public void adicionarNota(double nota) throws NotaInvalidaException {
        if (nota < 0.0 || nota > 10.0) {
            throw new NotaInvalidaException(nota);
        }
        notas.add(nota);
    }

    public List<Double> getNotas() {
        return Collections.unmodifiableList(notas);
    }

    /**
     * Calcula a média aritmética das notas.
     */
    public double calcularMedia() {
        if (notas.isEmpty()) {
            return 0.0;
        }
        double soma = 0.0;
        for (double nota : notas) {
            soma += nota;
        }
        return soma / notas.size();
    }

    /**
     * Retorna a maior nota do aluno.
     */
    public double getMaiorNota() {
        if (notas.isEmpty()) return 0.0;
        return Collections.max(notas);
    }

    /**
     * Retorna a menor nota do aluno.
     */
    public double getMenorNota() {
        if (notas.isEmpty()) return 0.0;
        return Collections.min(notas);
    }

    /**
     * Determina a situação do aluno.
     * Demonstra: polimorfismo (comportamento específico de Aluno).
     */
    public String getSituacao() {
        return calcularMedia() >= MEDIA_APROVACAO ? "Aprovado ✓" : "Reprovado ✗";
    }

    public boolean isAprovado() {
        return calcularMedia() >= MEDIA_APROVACAO;
    }

    /**
     * Ordena alunos por nome (para Collections.sort).
     * Demonstra: implementação de interface Comparable.
     */
    @Override
    public int compareTo(Aluno outro) {
        return this.getNome().compareToIgnoreCase(outro.getNome());
    }

    /**
     * Implementação do método abstrato de Pessoa.
     * Demonstra: polimorfismo (override de método abstrato).
     */
    @Override
    public String exibirInformacoes() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-25s", getNome()));
        sb.append(String.format(" | Média: %5.2f", calcularMedia()));
        sb.append(String.format(" | Situação: %-12s", getSituacao()));

        sb.append(" | Notas: [");
        for (int i = 0; i < notas.size(); i++) {
            sb.append(String.format("%.1f", notas.get(i)));
            if (i < notas.size() - 1) sb.append(", ");
        }
        sb.append("]");

        return sb.toString();
    }
}
